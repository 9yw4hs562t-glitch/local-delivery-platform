export default function Home() {
  return (
    <div>
      <h1>Plateforme de livraison locale</h1>
      <p>Autorisez la localisation pour continuer.</p>
      <button>Autoriser la localisation</button>
    </div>
  );
}